package com.example.cy_compiler;

public class MyClass {
}
