package com.example.changyi_core.activities;


import me.yokeyword.fragmentation.SupportActivity;

public class ProxyActivity extends SupportActivity {


}
