package com.example.cy_annotations;

public class MyClass {
}
